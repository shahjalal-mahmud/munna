
public class Problem3 {
    public static void main(String[] args) {
        
        double radius=7.5;
        double pi=3.1416;
        double area=pi*radius*radius;

        System.out.println("Area of circle:  "+area);
   } 
}
