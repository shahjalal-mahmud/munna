public class Problem8 {

    public static void main(String[] args) {
        int a=15;
        int b=25;
        int max;
    
        if (a>b){
            max=a;
        }else{
            max=b;
        }
        System.out.println(" The maximum number is: "+max);
    }
}
