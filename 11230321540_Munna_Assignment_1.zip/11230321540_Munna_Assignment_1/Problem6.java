

public class Problem6 {
    public static void main(String[] args) {
        int principle= 10000;
        double rate=5;
        int time=3;
        double S= (principle*rate*time)/100;

        System.out.println("Simple Interest: "+ S);
    }
}
