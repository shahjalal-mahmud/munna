public class Problem9 {
        public static void main(String[] args) {
                double num1=8.5;
                double num2=7.3;
                double num3=9.8;

                double average=(num1+num2+num3)/3.0;

                System.out.println("Average: "+average);
        
        }
}
