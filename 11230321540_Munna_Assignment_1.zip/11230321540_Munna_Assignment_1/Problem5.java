

public class Problem5 {
    public static void main(String[] args) {
        int x=10;
        int y=20;

        int temp =x;
        x=y;
        y=temp;

        System.out.println("After Swap x= "+x+ ", y= "+y);
    }
}
