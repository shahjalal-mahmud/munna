

public class Problem4 {
    public static void main(String[] args) {
        int c=25;
        double F=(c*9/5)+32;

        System.out.println("Temperature in Fahrenheit: "+F);
    }
}
