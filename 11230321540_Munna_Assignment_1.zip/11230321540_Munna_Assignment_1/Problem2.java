

public class Problem2 {
    public static void main (String [] args){
        int a=10;
        int b=5;

        int addi=a+b;
        int sub=a-b;
        int mul=a*b;
        double div=a/b;

        
        System.out.println("Addition : "+addi);
        System.out.println("Subtraction : "+sub);
        System.out.println("Multiplication  : "+mul);
        System.out.println("Division : "+div);

    }
}
